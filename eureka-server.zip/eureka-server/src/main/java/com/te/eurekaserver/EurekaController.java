package com.te.eurekaserver;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EurekaController {

	@RequestMapping("/")
	public String home() {
		return "Hello world";
	}
}
