package com.te.departmentservice.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.te.departmentservice.dto.RegisterDto;
import com.te.departmentservice.entity.Department;
import com.te.departmentservice.response.DeptResponse;
import com.te.departmentservice.service.DepartmentServiceImplementation;

import io.github.resilience4j.ratelimiter.RequestNotPermitted;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;

@RequestMapping("/DEPARTMENT")
@RestController
public class DepartmentController {
	@Autowired
	private DepartmentServiceImplementation implementation;
	Logger logger = LoggerFactory.getLogger(DepartmentController.class);

	
	@PostMapping("/REGISTER")
	@RateLimiter(name = "register", fallbackMethod = "getMessageFallBack")
	public ResponseEntity<DeptResponse> register(@RequestBody RegisterDto registerDto) {
		Department department = implementation.register(registerDto);
		DeptResponse deptResponse = DeptResponse.builder().data(department).error("false")
				.message("registered successfully").build();
		return new ResponseEntity<>(deptResponse, HttpStatus.ACCEPTED);

	}

	@PutMapping("/UPDATE/NAME/{deptId}")
	@RateLimiter(name = "updateDept", fallbackMethod = "getMessageFallBack")
	public ResponseEntity<DeptResponse> updateDept(@PathVariable String deptName, @PathVariable Integer deptId) {
		Department department = implementation.updateDeptName(deptName, deptId);
		DeptResponse deptResponse = DeptResponse.builder().data(department).error("false")
				.message("department Name updated successfully").build();
		return new ResponseEntity<>(deptResponse, HttpStatus.ACCEPTED);

	}

	@PutMapping("/UPDATE/LOCATION/{deptId}")
	@RateLimiter(name = "updateLocation", fallbackMethod = "getMessageFallBack")
//	@CircuitBreaker(name="",fallbackMethod = "")
	public ResponseEntity<DeptResponse> updateLocation(@PathVariable String deptLocation,
			@PathVariable Integer deptId) {
		Department department = implementation.updateDeptLocation(deptLocation, deptId);
		DeptResponse deptResponse = DeptResponse.builder().data(department).error("false")
				.message("department location updated successfully").build();
		return new ResponseEntity<>(deptResponse, HttpStatus.ACCEPTED);

	}

	@DeleteMapping("/DELETE")
	@RateLimiter(name = "deleteDept", fallbackMethod = "getMessageFallBack")
	public ResponseEntity<DeptResponse> deleteDept(@PathVariable Integer deptId) {
		implementation.deleteDept(deptId);
		DeptResponse deptResponse = DeptResponse.builder().error("false").message("department deleted successfully")
				.build();
		return new ResponseEntity<>(deptResponse, HttpStatus.ACCEPTED);

	}

	@PostMapping("/FETCH/{deptId}")
	@RateLimiter(name = "fetchDept", fallbackMethod = "getMessageFallBack")
	public Department fetchDept(@PathVariable Integer deptId) {
		return implementation.fetchDept(deptId);
//		DeptResponse deptResponse = DeptResponse.builder().error("false").data(department)
//				.message("department deleted successfully").build();
		

	}

	@GetMapping("/FETCHALL")
	@RateLimiter(name = "fetchAll", fallbackMethod = "getMessageFallBack")
	public ResponseEntity<DeptResponse> fetchAll() {
		List<Department> list = implementation.fetchAll();
		DeptResponse deptResponse = DeptResponse.builder().error("false").data(list)
				.message("department deleted successfully").build();
		return new ResponseEntity<>(deptResponse, HttpStatus.ACCEPTED);

	}
	
	public ResponseEntity<String> getMessageFallBack(RequestNotPermitted exception) {

		logger.info("Rate limit has applied, So no further calls are getting accepted");

		return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS)
				.body("Too many requests : No further request will be accepted. Please try after sometime");
	}

}
