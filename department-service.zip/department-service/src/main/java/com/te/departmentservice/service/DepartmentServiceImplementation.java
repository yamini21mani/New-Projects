package com.te.departmentservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.te.departmentservice.dto.RegisterDto;
import com.te.departmentservice.entity.Department;
import com.te.departmentservice.repository.DepartmentRepository;

@Service
public class DepartmentServiceImplementation {
	@Autowired
	private DepartmentRepository repository;

	public Department register(RegisterDto registerDto) {
		Department department=Department.builder().deptId(registerDto.getDeptId()).deptName(registerDto.getDeptName())
				.deptLocation(registerDto.getDeptLocation()).build();
		return repository.save(department);

	}

	public Department updateDeptName(String deptName,Integer deptId) {
		Department department = repository.findById(deptId).orElse(null);
		return Department.builder().deptId(department.getDeptId()).deptName(deptName).deptLocation(department.getDeptLocation()).build();
	}

	public Department updateDeptLocation(String deptLocation,Integer deptId) {
		Department department = repository.findById(deptId).orElse(null);
		return Department.builder().deptId(department.getDeptId()).deptName(department.getDeptName()).deptLocation(deptLocation).build();	}

	public void deleteDept(Integer deptId) {
		Department department = repository.findById(deptId).orElse(null);
		if(department!=null)
		repository.delete(department);
	}

	public Department fetchDept(Integer deptId) {
		Department department=repository.findById(deptId).orElse(null);
		return department;
		
	}

	public List<Department> fetchAll() {
		
		return repository.findAll();
	}

}
