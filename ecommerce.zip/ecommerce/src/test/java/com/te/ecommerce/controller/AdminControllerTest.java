package com.te.ecommerce.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import java.io.UnsupportedEncodingException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.te.ecommerce.dto.ProductDto;
import com.te.ecommerce.entity.Product;
import com.te.ecommerce.response.EcommerceResponse;
import com.te.ecommerce.serviceimplementation.ProductServiceImp;

//@SpringBootTest
@WebMvcTest(AdminController.class)
@ExtendWith(MockitoExtension.class)
class AdminControllerTest {

	@MockBean
	private AdminController adminController;
	@MockBean
	EcommerceResponse ecommerceResponse;
	private MockMvc mockMvc;
	@Autowired
	private WebApplicationContext context;

	@MockBean
	private ProductServiceImp productServiceImp;
	
	private ObjectMapper objectMapper = new ObjectMapper();


	@BeforeEach
	void setup() {
//    	EcommerceResponse.builder().message("Success").error(false).status("200").build();
		mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

	}

	@Test
	void testCreateProduct() throws UnsupportedEncodingException, Exception {
		ProductDto productDto = ProductDto.builder().productId(1).manufacturer("MAX").name("Shirt").price(699.00)
				.description("full hand shirt-women").build();
		Product product = Product.builder().productId(1).manufacturer("MAX").name("Shirt").price(699.00)
				.description("full hand shirt-women").build();
		when(productServiceImp.createProduct(productDto)).thenReturn(product);
		String result = mockMvc.perform(get("/admin/sortProduct/")).andExpect(MockMvcResultMatchers.status().isOk())
				.andReturn().getResponse().getContentAsString();
		EcommerceResponse response = objectMapper.readValue(result, EcommerceResponse.class);

		assertEquals(productDto, product);
//		assertEquals("200", response.getStatus());
//		assertEquals(result, response);
	}

	@Test
	void testGetProduct() {
//        ProductDto productDto = new ProductDto();
		ProductDto productDto = ProductDto.builder().productId(1).build();
		Product product = new Product();
		Product.builder().productId(1).manufacturer("MAX").name("Shirt").price(699.00)
				.description("full hand shirt-women").build();
		when(productServiceImp.getProduct(productDto)).thenReturn(product);

		ResponseEntity<EcommerceResponse> response = adminController.getProduct(productDto);
		assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
	}

	@Test
	void testUpdateProduct() {
//        ProductDto productDto = new ProductDto();
		ProductDto productDto = ProductDto.builder().productId(1).manufacturer("Sakki").name("Shirt").price(699.00)
				.description("full hand shirt-women").build();
		Product product = Product.builder().productId(1).manufacturer("MAX").name("Shirt").price(699.00)
				.description("full hand shirt-women").build();

		when(productServiceImp.updateProduct(productDto)).thenReturn(null);

		ResponseEntity<EcommerceResponse> response = adminController.updateProduct(productDto);
//        assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
		assertEquals(product, productDto);

	}

	@Test
	void testDeleteProduct() {
//        ProductDto productDto = new ProductDto();
		ProductDto productDto = ProductDto.builder().productId(1).manufacturer("Sakki").name("Shirt").price(699.00)
				.description("full hand shirt-women").build();
		Product product = Product.builder().build();

		when(productServiceImp.deleteProduct(productDto));

		ResponseEntity<EcommerceResponse> response = adminController.deleteProduct(productDto);
		assertNotEquals(productDto, product);
		assertNotNull(productDto);
	}
}
