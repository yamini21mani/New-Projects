package com.te.ecommerce.serviceimplementation;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.context.SpringBootTest;

import com.te.ecommerce.dto.RoleDto;
import com.te.ecommerce.entity.Roles;
import com.te.ecommerce.repository.RolesRepository;

@SpringBootTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
class AdminServiceImpTest {
	@Mock
	private RolesRepository repository;
	@Autowired
	private AdminServiceImp adminServiceImp;

	@BeforeEach
	void setUp() throws Exception {

	}

	@Test
	void testCreateRole() {
		RoleDto roleDto = new RoleDto();
		roleDto.setRoleName("Admin");
		Roles roles=Roles.builder().roleName("ADMIN").roleId(1).build();

		Mockito.when(repository.save(any(Roles.class))).thenReturn(roles);

		boolean createRole = adminServiceImp.createRole(roleDto);
		assertTrue(createRole);

	}

	@Test
	void testDeleteRole() {
		RoleDto roleDto = new RoleDto();
//		roleDto.setRoleName("Admin");
		roleDto.setRoleId(1);
		Roles roles = Roles.builder().roleId(1).roleName("ADMIN").build();
		repository.save(roles);
		Roles findById = repository.findById(1).orElseThrow();
		Mockito.when(findById).thenReturn(roles);
				
		 boolean deleteRole = adminServiceImp.deleteRole(roleDto);
		 assertTrue(deleteRole);
		

	}

}
