package com.te.ecommerce.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.te.ecommerce.entity.Roles;

public interface RolesRepository extends JpaRepository<Roles, Integer>{

}
