package com.te.ecommerce.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Component
@Builder
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer productId;
	@NotBlank(message = "product must have a name")
	private String name;
	@NotBlank(message = "product must have a category")
	private String category;
	@NotBlank(message = "product description cannot be empty")
	private String description;
	@NotBlank(message = "brand cannot be empty")
	private String manufacturer;
	@NotNull(message = "price cannot be empty")
	private double price;
	
	@ManyToMany(cascade = CascadeType.ALL)
	private List<CartItem> cartitem;
}
