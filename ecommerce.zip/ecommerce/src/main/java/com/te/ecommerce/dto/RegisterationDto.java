package com.te.ecommerce.dto;

import org.springframework.stereotype.Component;

import lombok.Data;
@Data
@Component
public class RegisterationDto {
	private String firstName;
	private String lastName;
	private Long phoneno;
	private String email;
	private Integer cartId;
	private String username;
	private String name;
	private String password;
	private String role;

}
