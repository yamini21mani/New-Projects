package com.te.ecommerce.entity;


import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Data
@Component
@Table
public class CartItem {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer cartItemId;
	@NotNull(message = "please enter the quantity")
	private Integer quantity;
	private double price;
	
	@ManyToMany(cascade = CascadeType.ALL)
	private List<Product> product;
	@ManyToOne (cascade = CascadeType.ALL)
	private Cart cart;
	@ManyToOne(cascade = CascadeType.ALL)
	private Customer customer;
	
	

}
