package com.te.ecommerce.serviceimplementation;

import java.io.File;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.te.ecommerce.dto.MessageDetails;
import com.te.ecommerce.serviceinterface.EmailService;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class EmailSenderServiceImp implements EmailService{
	
	private final JavaMailSender javaMailSender;
	@Value("${spring.mail.username}")
	private String sender;

//	public void sendSimpleEmail(String toEmail, String body, String subject) {
//		SimpleMailMessage mailMessage = new SimpleMailMessage();
//		mailMessage.setTo(toEmail);
//		mailMessage.setText(body);
//		mailMessage.setSubject(subject);
//		mailMessage.setFrom("yaminimani65@gmail.com");
//		javaMailSender.send(mailMessage);
//		System.out.println("Send email");
//	}
	public String sendSimpleEmail(MessageDetails messageDetails) {
		SimpleMailMessage mailMessage = new SimpleMailMessage();
		mailMessage.setTo(messageDetails.getToEmail());
		mailMessage.setText(messageDetails.getBody());
		mailMessage.setSubject(messageDetails.getSubject());
		mailMessage.setFrom(sender);
		javaMailSender.send(mailMessage);
		return "Mail Sent successfully";
	}

	public String sendEmailWithAttachment(MessageDetails messageDetails)
			throws MessagingException {
		MimeMessage mimeMessage = javaMailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
		helper.setFrom(sender);
		helper.setCc(messageDetails.getCc());
		helper.setText(messageDetails.getBody());
		helper.setSubject(messageDetails.getSubject());
		FileSystemResource resource = new FileSystemResource(new File(messageDetails.getAttachment()));

		helper.addAttachment(resource.getFilename(), resource);
		javaMailSender.send(mimeMessage);
//		System.out.println("mail sent");
		return "mail sent";
	}

}
