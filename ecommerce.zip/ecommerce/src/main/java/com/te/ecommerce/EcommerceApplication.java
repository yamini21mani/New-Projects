package com.te.ecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//@PropertySource("classpath:ecommerce.propeties")
public class EcommerceApplication {

//	@Autowired
//	private EmailSenderServiceImp emailSenderService;
//	@Autowired
//	private MessageDetails messageDetails;

	public static void main(String[] args) {
		SpringApplication.run(EcommerceApplication.class, args);
	}

//	@EventListener(ApplicationReadyEvent.class)
//	public void triggerMail() {
//		emailSenderService.sendSimpleEmail(MessageDetails messageDetails);
//
////		emailSenderService.sendEmailWithAttachment("veenal.c@testyantra.com", "this is test email from yamini", "Test Email", "C:\\Users\\yamin\\OneDrive\\Documents\\collection shortnotes.docx");
//	}

}
