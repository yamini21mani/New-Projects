package com.te.ecommerce.entity;


import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@Component
public class ShippingAddress {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer shippingAddressId;
	@NotBlank(message = "enter the street")
	private String address;
	@NotBlank(message = "city is missing")
	private String city;
	@NotBlank(message = "state is missing")
	private String state;
	@NotNull(message = "zipcode is missing")
	private Integer zipcode;
	@NotBlank(message = "country is missing")
	private String country;
	
	@ManyToOne(cascade = CascadeType.ALL)
	private Customer customer;

}
