package com.te.ecommerce.serviceinterface;

import javax.mail.MessagingException;

import com.te.ecommerce.dto.MessageDetails;


public interface EmailService {
	public String sendSimpleEmail(MessageDetails messageDetails);
	public String sendEmailWithAttachment(MessageDetails messageDetails) throws MessagingException;

}
