package com.te.ecommerce.serviceimplementation;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.te.ecommerce.dto.AddressDto;
import com.te.ecommerce.entity.BillingAddress;
import com.te.ecommerce.entity.Customer;
import com.te.ecommerce.exceptionhandling.GeneralException;
import com.te.ecommerce.repository.BillingAddressRepository;
import com.te.ecommerce.repository.CustomerRepository;
import com.te.ecommerce.serviceinterface.BillingAddressInterface;

@Service
public class BillingAddressServImp implements BillingAddressInterface {
	@Autowired
	private BillingAddressRepository billingAddressRepository;
	@Autowired
	private BillingAddress billingAddress;
	@Autowired
	CustomerRepository customerRepository;

	@Override
	public BillingAddress addBillingAddress(AddressDto addressDto) {
		Customer customer = new Customer();
		BeanUtils.copyProperties(addressDto, customer);
		Customer adddata = customerRepository.findById(customer.getId())
				.orElseThrow(() -> new GeneralException("Unable to add address"));
		if (adddata != null) {
			BeanUtils.copyProperties(addressDto, billingAddress);
//			billingAddress.setCustomer(adddata);
//			billingAddress.set
			billingAddressRepository.save(billingAddress);
			return billingAddress;
		} else
			throw new GeneralException("unable to add Address Please check");
	}

	@Override
	public BillingAddress getBillingAddress(AddressDto addressDto) {
		Customer customer = new Customer();
		BeanUtils.copyProperties(addressDto, customer);
		customerRepository.findById(customer.getId()).orElseThrow(() -> new GeneralException("no id found"));
		BeanUtils.copyProperties(addressDto, billingAddress);

//		billingAddressRepository.save(billingAddress);
		return billingAddressRepository.findById(billingAddress.getBillingAddressId())
				.orElseThrow(() -> new GeneralException("No data found please check the id"));
	}

	@Override
	public BillingAddress updateBillingAddress(AddressDto addressDto) {
		BeanUtils.copyProperties(addressDto, billingAddress);
		BillingAddress founddata = billingAddressRepository.findById(billingAddress.getBillingAddressId())
				.orElseThrow(() -> new GeneralException("No data found please check the ID"));
		founddata.setAddress(addressDto.getAddress());
		founddata.setCity(addressDto.getCity());
		founddata.setCountry(addressDto.getCountry());
		founddata.setState(addressDto.getState());
		founddata.setZipcode(addressDto.getZipcode());
		return billingAddressRepository.save(founddata);

	}

	public void deleteBillingAddress(AddressDto addressDto) {
		BeanUtils.copyProperties(addressDto, billingAddress);
		BillingAddress founddata = billingAddressRepository.findById(billingAddress.getBillingAddressId())
				.orElseThrow(() -> new GeneralException("No data found please check the ID"));
		billingAddressRepository.delete(founddata);
	}

	@Override
	public List<BillingAddress> billingAddressList() {
		return billingAddressRepository.findAll();
	}

}
