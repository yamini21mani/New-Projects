package com.te.ecommerce.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class LoginDto {
	@NotBlank(message = "username cannot be empty")
	private String username;
	@NotBlank(message = "name cannot be empty")
	private String name;
	@NotBlank(message = "password should be minimum 8 characters")
	@Size(min = 8,max = 16)
	private String password;
}
