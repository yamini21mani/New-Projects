package com.te.ecommerce.dto;

import org.springframework.stereotype.Component;

import lombok.Data;
@Data
@Component
public class UserDto {
	private String username;
	private String name;
	private String password;
}
