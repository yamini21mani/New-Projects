package com.te.ecommerce.serviceimplementation;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.te.ecommerce.dto.AddressDto;
import com.te.ecommerce.entity.Customer;
import com.te.ecommerce.entity.ShippingAddress;
import com.te.ecommerce.exceptionhandling.GeneralException;
import com.te.ecommerce.repository.CustomerRepository;
import com.te.ecommerce.repository.ShippingAddressRepository;
import com.te.ecommerce.serviceinterface.ShippingAddressInterface;

@Service
public class ShippingAddressServImp implements ShippingAddressInterface {
	@Autowired
	private ShippingAddress shippingAddress;
	@Autowired
	private ShippingAddressRepository shippingAddressRepository;
	
	@Autowired CustomerRepository customerRepository;
	
	@Override
	public ShippingAddress addShippingAddress(AddressDto addressDto) {
		Customer customer=new Customer();
		BeanUtils.copyProperties(addressDto, customer);
		Customer adddata = customerRepository.findById(customer.getId()).orElseThrow(()-> new GeneralException("Unable to add address"));
		if(adddata!=null) {
		BeanUtils.copyProperties(addressDto, shippingAddress);
		 shippingAddressRepository.save(shippingAddress);
			return shippingAddress;
		}
		else
			throw new GeneralException("unable to add Address Please check");
	}

	@Override
	public ShippingAddress getShippingAddress(AddressDto addressDto) {
		BeanUtils.copyProperties(addressDto, shippingAddress);
		return shippingAddressRepository.findById(shippingAddress.getShippingAddressId())
				.orElseThrow(() -> new GeneralException("No data found please check the id"));
	}

	@Override
	public ShippingAddress updateShippingAddress(AddressDto addressDto) {
		BeanUtils.copyProperties(addressDto, shippingAddress);
		ShippingAddress founddata = shippingAddressRepository.findById(shippingAddress.getShippingAddressId())
				.orElseThrow(() -> new GeneralException("No data found please check the ID"));
		founddata.setAddress(addressDto.getAddress());
		founddata.setCity(addressDto.getCity());
		founddata.setCountry(addressDto.getCountry());
		founddata.setState(addressDto.getState());
		founddata.setZipcode(addressDto.getZipcode());
		return shippingAddressRepository.save(founddata);
	}

	@Override
	public void deleteShippingAddress(AddressDto addressDto) {
		BeanUtils.copyProperties(addressDto, shippingAddress);
		ShippingAddress founddata = shippingAddressRepository.findById(shippingAddress.getShippingAddressId()).orElseThrow(()-> new GeneralException("No data found please check the ID"));
		shippingAddressRepository.delete(founddata);
	}

	@Override
	public List<ShippingAddress> shippingAddressList() {
		return shippingAddressRepository.findAll();		
	}

	

	
}
