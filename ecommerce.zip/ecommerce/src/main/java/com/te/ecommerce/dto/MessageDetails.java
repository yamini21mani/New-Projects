package com.te.ecommerce.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

import org.springframework.stereotype.Component;

import lombok.Data;
@Component
@Data
public class MessageDetails {
	@NotBlank
	@Email
	private String toEmail;
	private String body; 
	private String subject;
	@Email
	@NotBlank
//	private String from;
	private String attachment;
	private String cc;
//	private String bcc;

}
