package com.te.ecommerce.springsecurity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.te.ecommerce.entity.User;
import com.te.ecommerce.repository.UserRepository;
import com.te.ecommerce.serviceinterface.UserServiceInterface;

@Service
public class UserServiceImp implements UserDetailsService, UserServiceInterface {

	@Autowired
	UserRepository userRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = userRepository.findUserByUsername(username);
		if (user == null) {
			throw new UsernameNotFoundException("Please check the user name");
		} else {
			return new CustomUserDetails(user);
		}
	}

}
