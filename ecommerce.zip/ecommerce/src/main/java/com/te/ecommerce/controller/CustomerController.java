package com.te.ecommerce.controller;


import java.util.List;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
//import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.te.ecommerce.dto.AddressDto;
import com.te.ecommerce.dto.CustomerDto;
import com.te.ecommerce.dto.LoginDto;
import com.te.ecommerce.dto.MessageDetails;
import com.te.ecommerce.dto.ProductDto;
import com.te.ecommerce.dto.RegisterationDto;
import com.te.ecommerce.entity.BillingAddress;
import com.te.ecommerce.entity.Customer;
import com.te.ecommerce.entity.Product;
import com.te.ecommerce.entity.SalesOrder;
import com.te.ecommerce.entity.ShippingAddress;
import com.te.ecommerce.response.EcommerceResponse;
import com.te.ecommerce.serviceimplementation.BillingAddressServImp;
import com.te.ecommerce.serviceimplementation.CustomerServiceImp;
import com.te.ecommerce.serviceimplementation.EmailSenderServiceImp;
import com.te.ecommerce.serviceimplementation.ProductServiceImp;
import com.te.ecommerce.serviceimplementation.ShippingAddressServImp;
import com.te.ecommerce.serviceimplementation.SmsService;
import com.te.ecommerce.springsecurity.UserServiceImp;

@RestController
@RequestMapping("/CUSTOMER")
public class CustomerController {
	
	@Autowired 
	private EmailSenderServiceImp emailService;
	@Autowired
	private EcommerceResponse ecommerceResponse;
	@Autowired
	private CustomerServiceImp serviceImp;
	@Autowired
	private ShippingAddressServImp shippingAddressServImp;
	@Autowired
	private BillingAddressServImp billingAddressServImp;
	@Autowired
	private ProductServiceImp productServiceImp;
//	@Autowired
//	private JwtUtil util;
//	@Autowired
//	private AuthenticationManager authenticationManager;
	@Autowired
	private UserServiceImp userServiceImp;
	@Autowired
    SmsService service;

//    @Autowired
//    private WebSocket webSocket;

//    private final String  TOPIC_DESTINATION = "/lesson/sms";
//registeration
	@PostMapping("/register")
	@PreAuthorize(value="hasAnyRole('ADMIN','CUSTOMER')")
	public ResponseEntity<EcommerceResponse> register(@RequestBody RegisterationDto registerationDto) {
		Customer register = serviceImp.register(registerationDto);
		ecommerceResponse.setMessage("registeration successful");
		ecommerceResponse.setError(false);
		ecommerceResponse.setStatus("200");
		ecommerceResponse.setData(register.getId());
		return new ResponseEntity<>(ecommerceResponse, HttpStatus.ACCEPTED);

	}

	@GetMapping("/getProductdetails")
	@PreAuthorize(value="hasAnyRole('ADMIN','CUSTOMER')")
	public ResponseEntity<EcommerceResponse> getProduct(@RequestBody ProductDto productDto) {
		Product product = productServiceImp.getProduct(productDto);
		ecommerceResponse.setError(false);
		ecommerceResponse.setStatus("200");
		ecommerceResponse.setData(product);
		return new ResponseEntity<>(ecommerceResponse, HttpStatus.ACCEPTED);
	}

//Search products by name, id and category
	@GetMapping("/searchproductbyId")
	@PreAuthorize(value="hasAnyRole('ADMIN','CUSTOMER')")
	public ResponseEntity<EcommerceResponse> searchProductbyId(@RequestBody ProductDto productDto) {
		serviceImp.searchProductbyId(productDto);
		ecommerceResponse.setError(false);
		ecommerceResponse.setStatus("200");
		return new ResponseEntity<>(ecommerceResponse, HttpStatus.ACCEPTED);

	}

	@GetMapping("/searchProductbyName")
	@PreAuthorize(value="hasAnyRole('ADMIN','CUSTOMER')")
	public ResponseEntity<EcommerceResponse> searchProductbyName(@RequestBody ProductDto productDto) {
		serviceImp.searchProductbyName(productDto);
		ecommerceResponse.setError(false);
		ecommerceResponse.setStatus("200");
		return new ResponseEntity<>(ecommerceResponse, HttpStatus.ACCEPTED);

	}

	@GetMapping("/searchProductbyCategory")
	@PreAuthorize(value="hasAnyRole('ADMIN','CUSTOMER')")
	public ResponseEntity<EcommerceResponse> searchProductbyCategory(@RequestBody ProductDto productDto) {
		serviceImp.searchProductbyCategory(productDto);
		ecommerceResponse.setError(false);
		ecommerceResponse.setStatus("200");
		return new ResponseEntity<>(ecommerceResponse, HttpStatus.ACCEPTED);

	}

//fetch products list
	@GetMapping("/productlist")
	@PreAuthorize(value="hasAnyRole('ADMIN','CUSTOMER')")
	public ResponseEntity<EcommerceResponse> productList() {
		List<Product> findAll = serviceImp.productList();
		ecommerceResponse.setError(false);
		ecommerceResponse.setStatus("200");
		ecommerceResponse.setData(findAll);
		return new ResponseEntity<>(ecommerceResponse, HttpStatus.ACCEPTED);

	}

//CRUD customer API's
	@PutMapping("/updateCustomer")
	@PreAuthorize(value="hasAnyRole('ADMIN','CUSTOMER')")
	public ResponseEntity<EcommerceResponse> updateCustomer(@RequestBody CustomerDto customerDto) {
		Customer updateCustomer = serviceImp.updateCustomer(customerDto);
		ecommerceResponse.setMessage("Customer data modified successfully");
		ecommerceResponse.setError(false);
		ecommerceResponse.setStatus("200");
		ecommerceResponse.setData(updateCustomer);
		return new ResponseEntity<>(ecommerceResponse, HttpStatus.ACCEPTED);

	}

	@DeleteMapping("/deleteCustomer")
	@PreAuthorize(value="hasAnyRole('ADMIN','CUSTOMER')")
	public ResponseEntity<EcommerceResponse> deleteCustomer(@RequestBody CustomerDto customerDto) {
		serviceImp.deleteCustomer(customerDto);
		ecommerceResponse.setMessage("Customer data deleted successfully");
		ecommerceResponse.setError(false);
		ecommerceResponse.setStatus("200");
		return new ResponseEntity<>(ecommerceResponse, HttpStatus.ACCEPTED);

	}

	@PostMapping("/getCustomer")
	@PreAuthorize(value="hasAnyRole('ADMIN','CUSTOMER')")
	public ResponseEntity<EcommerceResponse> getCustomer(@RequestBody CustomerDto customerDto) {
		Customer customer = serviceImp.getCustomer(customerDto);
		ecommerceResponse.setError(false);
		ecommerceResponse.setStatus("200");
		ecommerceResponse.setData(customer);
		return new ResponseEntity<>(ecommerceResponse, HttpStatus.ACCEPTED);

	}

//Shipping Address CRUD
	@PostMapping("/addShippingAddress")
	@PreAuthorize(value="hasAnyRole('ADMIN','CUSTOMER')")
	public ResponseEntity<EcommerceResponse> addShippingAddress(@RequestBody AddressDto addressDto) {
		ShippingAddress updateCustomer = shippingAddressServImp.addShippingAddress(addressDto);
		ecommerceResponse.setMessage("Shipping address added successfully");
		ecommerceResponse.setError(false);
		ecommerceResponse.setStatus("200");
		ecommerceResponse.setData(updateCustomer);
		return new ResponseEntity<>(ecommerceResponse, HttpStatus.ACCEPTED);

	}

	@GetMapping("/getShippingAddress")
	@PreAuthorize(value="hasAnyRole('ADMIN','CUSTOMER')")
	public ResponseEntity<EcommerceResponse> getShippingAddress(@RequestBody AddressDto addressDto) {
		ShippingAddress updateCustomer = shippingAddressServImp.getShippingAddress(addressDto);
		ecommerceResponse.setMessage("shipping address is fetched successfully");
		ecommerceResponse.setError(false);
		ecommerceResponse.setStatus("200");
		ecommerceResponse.setData(updateCustomer);
		return new ResponseEntity<>(ecommerceResponse, HttpStatus.ACCEPTED);

	}

	@PostMapping("/updateShippingAddress")
	@PreAuthorize(value="hasAnyRole('ADMIN','CUSTOMER')")
	public ResponseEntity<EcommerceResponse> updateShippingAddress(@RequestBody AddressDto addressDto) {
		ShippingAddress updateCustomer = shippingAddressServImp.updateShippingAddress(addressDto);
		ecommerceResponse.setMessage("Shipping address is updated successfully");
		ecommerceResponse.setError(false);
		ecommerceResponse.setStatus("200");
		ecommerceResponse.setData(updateCustomer);
		return new ResponseEntity<>(ecommerceResponse, HttpStatus.ACCEPTED);

	}

	@DeleteMapping("/deleteshippingAddress")
	@PreAuthorize(value="hasAnyRole('ADMIN','CUSTOMER')")
	public ResponseEntity<EcommerceResponse> deleteShippingAddress(@RequestBody AddressDto addressDto) {
		shippingAddressServImp.deleteShippingAddress(addressDto);
		ecommerceResponse.setMessage("Shipping Address is deleted successfully");
		ecommerceResponse.setError(false);
		ecommerceResponse.setStatus("200");
		return new ResponseEntity<>(ecommerceResponse, HttpStatus.ACCEPTED);

	}

	@PostMapping("/addBillingAddress")
	@PreAuthorize(value="hasAnyRole('ADMIN','CUSTOMER')")
	public ResponseEntity<EcommerceResponse> addBillingAddress(@RequestBody AddressDto addressDto) {
		BillingAddress addaddress = billingAddressServImp.addBillingAddress(addressDto);
		ecommerceResponse.setMessage("billing address is added successfully");
		ecommerceResponse.setError(false);
		ecommerceResponse.setStatus("200");
		ecommerceResponse.setData(addaddress);
		return new ResponseEntity<>(ecommerceResponse, HttpStatus.ACCEPTED);

	}

	@PostMapping("/getBillingAddress")
	@PreAuthorize(value="hasAnyRole('ADMIN','CUSTOMER')")
	public ResponseEntity<EcommerceResponse> getBillingAddress(@RequestBody AddressDto addressDto) {
		BillingAddress getaddress = billingAddressServImp.getBillingAddress(addressDto);
		ecommerceResponse.setMessage("billing address is fetched successfully");
		ecommerceResponse.setError(false);
		ecommerceResponse.setStatus("200");
		ecommerceResponse.setData(getaddress.getBillingAddressId());
		return new ResponseEntity<>(ecommerceResponse, HttpStatus.ACCEPTED);

	}

	@PostMapping("/updateBillingAddress")
	@PreAuthorize(value="hasAnyRole('ADMIN','CUSTOMER')")
	public ResponseEntity<EcommerceResponse> updateBillingAddress(@RequestBody AddressDto addressDto) {
		BillingAddress updateCustomer = billingAddressServImp.updateBillingAddress(addressDto);
		ecommerceResponse.setMessage("Billing Address is updated successfully");
		ecommerceResponse.setError(false);
		ecommerceResponse.setStatus("200");
		ecommerceResponse.setData(updateCustomer);
		return new ResponseEntity<>(ecommerceResponse, HttpStatus.ACCEPTED);

	}

	@PostMapping("/deleteBillingAddress")
	@PreAuthorize(value="hasAnyRole('ADMIN','CUSTOMER')")
	public ResponseEntity<EcommerceResponse> deleteBillingAddress(@RequestBody AddressDto addressDto) {
		billingAddressServImp.deleteBillingAddress(addressDto);
		ecommerceResponse.setMessage("Billing Address deleted successfully");
		ecommerceResponse.setError(false);
		ecommerceResponse.setStatus("200");
		return new ResponseEntity<>(ecommerceResponse, HttpStatus.ACCEPTED);

	}

	@PostMapping("/createsalesorder")
	@PreAuthorize(value="hasAnyRole('ADMIN','CUSTOMER')")
	public ResponseEntity<EcommerceResponse> createSalesOrder(@RequestBody AddressDto addressDto,
			@RequestBody CustomerDto customerDto) {
		SalesOrder order = serviceImp.createSalesOrder(addressDto, customerDto);
		ecommerceResponse.setMessage(" Sales order created Successfully");
		ecommerceResponse.setData(order);
		return new ResponseEntity<>(ecommerceResponse, HttpStatus.ACCEPTED);
	}

	@GetMapping("/shippingaddressList")
	@PreAuthorize(value="hasAnyRole('ADMIN','CUSTOMER')")
	public ResponseEntity<EcommerceResponse> shippingaddressList() {
		List<ShippingAddress> addressList = shippingAddressServImp.shippingAddressList();
		ecommerceResponse.setMessage(" Address List ");
		ecommerceResponse.setData(addressList);
		return new ResponseEntity<>(ecommerceResponse, HttpStatus.ACCEPTED);
	}

	@GetMapping("/billingaddressList")
	@PreAuthorize(value="hasAnyRole('ADMIN','CUSTOMER')")
	public ResponseEntity<EcommerceResponse> billingaddressList() {
		List<BillingAddress> addressList = billingAddressServImp.billingAddressList();
		ecommerceResponse.setMessage(" Address List");
		ecommerceResponse.setData(addressList);
		return new ResponseEntity<>(ecommerceResponse, HttpStatus.ACCEPTED);
	}

	@PostMapping("/login")
	@PreAuthorize(value="hasAnyRole('ADMIN','CUSTOMER')")
	public ResponseEntity<EcommerceResponse> login(@RequestBody LoginDto loginDto) {
		UserDetails loadUserByUsername = userServiceImp.loadUserByUsername(loginDto.getUsername());
		ecommerceResponse.setMessage("Successfully authenticated");
		ecommerceResponse.setData(loadUserByUsername);
		return new ResponseEntity<>(ecommerceResponse, HttpStatus.ACCEPTED);
	}
//	@PostMapping("/sms")
//    public void smsSubmit(@RequestBody SmsPojo sms) {
//        try{
//            service.send(sms);
//        }
//        catch(Exception e){
//
//        	webSocket.convertAndSend(TOPIC_DESTINATION, getTimeStamp() +
//            		": Error sending the SMS: "+e.getMessage());
//            throw e;
//        }
//        webSocket.convertAndSend(TOPIC_DESTINATION, getTimeStamp() + ": SMS has been sent!: "+sms.getTo());
//
//    }
//	 @PostMapping("/smscallback")
//	    public void smsCallback(@RequestBody MultiValueMap<String, String> map) {
//	       service.receive(map);
//	       webSocket.convertAndSend(TOPIC_DESTINATION, getTimeStamp() + 
//	    		   ": Twilio has made a callback request! Here are the contents: "+map.toString());
//	    }
//
//	    private String getTimeStamp() {
//	       return DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(LocalDateTime.now());
//	    }
	    
	    @PostMapping("/withAttachment")
		public ResponseEntity<EcommerceResponse> sendEmailAttachment(@RequestBody MessageDetails messageDetails) {
			try {
				String attachment = emailService.sendEmailWithAttachment(messageDetails);
				ecommerceResponse.setData(attachment);
				ecommerceResponse.setStatus("200");
				ecommerceResponse.setMessage("mail sent successfully");
				ecommerceResponse.setError(false);
				return new ResponseEntity<>(ecommerceResponse,HttpStatus.ACCEPTED);

			} catch (MessagingException e) {
				e.printStackTrace();
			}
			ecommerceResponse.setMessage("Unable to send email");
			return new ResponseEntity<>(ecommerceResponse,HttpStatus.BAD_GATEWAY);

		}
	    @PostMapping("/withoutAttachment")
		public ResponseEntity<EcommerceResponse> sendEmail(@RequestBody MessageDetails messageDetails) throws MessagingException {
			String attachment = emailService.sendSimpleEmail(messageDetails);
			ecommerceResponse.setData(attachment);
			ecommerceResponse.setStatus("200");
			ecommerceResponse.setMessage("mail sent successfully");
			ecommerceResponse.setError(false);
			return new ResponseEntity<>(ecommerceResponse,HttpStatus.ACCEPTED);
			

		}
}
