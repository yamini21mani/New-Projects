package com.te.ecommerce.serviceimplementation;

import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.te.ecommerce.dto.CartItemDto;
import com.te.ecommerce.dto.ProductDto;
import com.te.ecommerce.entity.Cart;
import com.te.ecommerce.entity.CartItem;
import com.te.ecommerce.entity.Customer;
import com.te.ecommerce.entity.Product;
import com.te.ecommerce.exceptionhandling.CartException;
import com.te.ecommerce.exceptionhandling.ProductException;
import com.te.ecommerce.repository.CartItemRepository;
import com.te.ecommerce.repository.CartRepository;
import com.te.ecommerce.repository.CustomerRepository;
import com.te.ecommerce.repository.ProductRepository;
import com.te.ecommerce.serviceinterface.ProductService;

@Service
public class ProductServiceImp implements ProductService {
	@Autowired
	private ProductRepository productRepository;
	@Autowired
	private CartItemRepository cartItemRepository;
	@Autowired
	private CartRepository cartRepository;

	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public Product createProduct(ProductDto productDto) {
		Product product = Product.builder().build();
		BeanUtils.copyProperties(productDto, product);
		productRepository.save(product);
		return productRepository.findById(product.getProductId())
				.orElseThrow(() -> new ProductException("Unable to add product"));

	}

	@Override
	public Product getProduct(ProductDto productDto) {
		Product product = Product.builder().build();
		BeanUtils.copyProperties(productDto, product);
		return productRepository.findById(product.getProductId())
				.orElseThrow(() -> new ProductException("No data found, please check the product ID"));

	}

	@Override
	public boolean updateProduct(ProductDto productDto) {
		Product product = Product.builder().build();
		BeanUtils.copyProperties(productDto, product);
		Product foundproduct = productRepository.findById(product.getProductId())
				.orElseThrow(() -> new ProductException("Please Check the product ID"));
		foundproduct.setName(productDto.getName());
		foundproduct.setCategory(productDto.getCategory());
		foundproduct.setPrice(productDto.getPrice());
		foundproduct.setDescription(productDto.getDescription());
		foundproduct.setManufacturer(productDto.getManufacturer());
		productRepository.save(product);
		return true;

	}

	@Override
	public boolean deleteProduct(ProductDto productDto) {
		Product product = Product.builder().build();
		BeanUtils.copyProperties(productDto, product);
		Product foundproduct = productRepository.findById(product.getProductId())
				.orElseThrow(() -> new ProductException("Unable to Delete the data, please check the Product ID"));
		productRepository.delete(foundproduct);
		return true;
	}

	@Override
	public CartItem addCartItem(CartItemDto cartItemDto) {
		Product product = Product.builder().build();
		BeanUtils.copyProperties(cartItemDto, product);
		Product getProduct = productRepository.findById(product.getProductId())
				.orElseThrow(() -> new ProductException("No product available with given id"));
		CartItem cartItem = new CartItem();
		BeanUtils.copyProperties(getProduct, cartItem);

//		cartItem.setCartItemId(productDto.getProductId());
		cartItem.setQuantity(cartItemDto.getQuantity());
		cartItem.setPrice(getProduct.getPrice() * cartItemDto.getQuantity());
		CartItem save = cartItemRepository.save(cartItem);
		if (save != null)
			return save;
		else
			throw new CartException("unable to add Cart item");
	}

	@Override
	public void deleteCartItem(CartItemDto cartItemDto) {
		CartItem cartItem = new CartItem();
		BeanUtils.copyProperties(cartItemDto, cartItem);
		CartItem deleteCart = cartItemRepository.findById(cartItem.getCartItemId()).orElse(null);
		Customer customer=new Customer();
		BeanUtils.copyProperties(cartItem, customer);
		if (deleteCart != null)
			cartItemRepository.delete(deleteCart);
		else
			throw new CartException("Unable to delete cart item");
	}
//	@Override
//	public List<CartItem> getAllCartItem(CartItemDto cartItemDto) {
//		CartItem cartItem = new CartItem();
//		Customer customer=new Customer();
//		BeanUtils.copyProperties(cartItemDto, cartItem);
//		BeanUtils.copyProperties(cartItemDto, customer);
//		Customer byId = customerRepository.getById(customer.getId());
//		cartItemRepository.findAll().stream().filter(cartitem-> cartitem.getCustomer(byId.getId()));
//		
//			throw new CartException("Unable to delete cart item");
//	}
	
	

	@Override
	public Double createCart(Customer customer) {
		Cart cart = new Cart();

		Optional<Customer> findById = customerRepository.findById(customer.getId());
		Customer cust = findById.get();
		
		Double totalPrice = cartItemRepository.findAll().stream().collect(Collectors.summingDouble(CartItem::getPrice));
		cart.setTotalPrice(totalPrice);
		cart.setCartId(customer.getId());
		cart.setCustomer(cust);
		cartRepository.save(cart);
		

		return totalPrice;
	}

}
