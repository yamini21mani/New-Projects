package com.te.ecommerce.dto;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Getter
@Setter
@Component
@NoArgsConstructor
@AllArgsConstructor
public class ProductDto {
	private Integer productId;
//	private Integer id;
	private String category;
	private String description;
	private String manufacturer;
	private String name;
	private double price;
//	private Integer quantity;
//	private String unit;
}
