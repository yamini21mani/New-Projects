package com.te.ecommerce.serviceinterface;

import java.util.List;

import com.te.ecommerce.dto.AddressDto;
import com.te.ecommerce.entity.BillingAddress;

public interface BillingAddressInterface {
	public BillingAddress addBillingAddress(AddressDto addressDto);
	public BillingAddress getBillingAddress(AddressDto addressDto);
	public BillingAddress updateBillingAddress(AddressDto addressDto);
	public void deleteBillingAddress(AddressDto addressDto);
	public List<BillingAddress> billingAddressList();


}
