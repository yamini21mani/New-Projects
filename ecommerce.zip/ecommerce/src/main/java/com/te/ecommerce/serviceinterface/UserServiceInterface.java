package com.te.ecommerce.serviceinterface;

import org.springframework.security.core.userdetails.UserDetails;

public interface UserServiceInterface {
	UserDetails loadUserByUsername(String username);
}
