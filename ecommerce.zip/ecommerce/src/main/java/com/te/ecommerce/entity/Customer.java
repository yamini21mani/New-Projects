package com.te.ecommerce.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Entity
@Data
@Component
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	@NotBlank(message = "First name cannot be blank")
	private String firstName;
	@NotEmpty (message = "Last name cannot be empty")
	private String lastName;
	private Long phoneno;
	@Email(message = "must be filled")
	private String email;

	@OneToOne(cascade = CascadeType.ALL)
	private Cart cart;
	@OneToOne(cascade = CascadeType.ALL)
	private User user;
	@OneToMany
	private List<BillingAddress> billingAddress;	
	@OneToMany
	private List<ShippingAddress> shippingAddress;
	@OneToMany
	private List<CartItem> cartItems;
	

}
