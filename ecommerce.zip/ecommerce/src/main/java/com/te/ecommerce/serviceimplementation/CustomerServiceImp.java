package com.te.ecommerce.serviceimplementation;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.te.ecommerce.dto.AddressDto;
import com.te.ecommerce.dto.CustomerDto;
import com.te.ecommerce.dto.ProductDto;
import com.te.ecommerce.dto.RegisterationDto;
import com.te.ecommerce.entity.Cart;
import com.te.ecommerce.entity.Customer;
import com.te.ecommerce.entity.Product;
import com.te.ecommerce.entity.SalesOrder;
import com.te.ecommerce.entity.User;
import com.te.ecommerce.exceptionhandling.CredentialsException;
import com.te.ecommerce.exceptionhandling.GeneralException;
import com.te.ecommerce.exceptionhandling.ProductException;
import com.te.ecommerce.repository.CartRepository;
import com.te.ecommerce.repository.CustomerRepository;
import com.te.ecommerce.repository.ProductRepository;
import com.te.ecommerce.repository.SalesOrderRepository;
import com.te.ecommerce.serviceinterface.CustomerService;

@Service
public class CustomerServiceImp implements CustomerService {
	@Autowired
	private CustomerRepository customerRepository;
	@Autowired
	private ProductRepository productRepository;
	@Autowired
	private SalesOrderRepository salesOrderRepository;
	@Autowired
	ShippingAddressServImp shippingAddressServImp;

//	@Autowired
//	private ShippingAddressRepository shippingAddressRepository;
//	@Autowired
//	private BillingAddressRepository billingAddressRepository;
//	 @Autowired private UserRepository userRepository;
	@Autowired
	private CartRepository cartRepository;
//	@Autowired
//	private ShippingAddress shippingAddress;
	@Autowired
	private SalesOrder salesOrder;
//	@Autowired
//	private BillingAddress billingAddress;
//	@Autowired
//	private Cart cart;
	@Autowired
	private BCryptPasswordEncoder encoder;

//registeration
	public Customer register(RegisterationDto registerationDto) {
		User user = User.builder().name(registerationDto.getName()).username(registerationDto.getUsername()).password(encoder.encode(registerationDto.getPassword())).role(registerationDto.getRole()).build();
//		User user = new User(registerationDto.getUsername(), registerationDto.getPassword(), registerationDto.getRole());
//		user.setPassword(encoder.encode(registerationDto.getPassword()));
		Customer customer=new Customer();
		BeanUtils.copyProperties(registerationDto, customer);
		customer.setUser(user);
		Cart cart=new Cart();
		cart.setCartId(registerationDto.getCartId());
		customer.setCart(cart);
		customerRepository.save(customer);
		Optional<Cart> findById = cartRepository.findById(cart.getCartId());
		Cart cartop = findById.get();
		cartop.setCartId(customer.getId());
		cartRepository.save(cartop);
		Customer registerdetails = customerRepository.save(customer);
		if(registerdetails!=null)
			return registerdetails;
		else
			throw new CredentialsException("Something went wrong");
	}

//Search API's
	@Override
	public Product searchProductbyId(ProductDto productDto) {
		List<Product> allproducts = productRepository.findAll();
		for (Product product : allproducts) {
			if (productDto.getProductId().equals(product.getProductId()))
				return product;
			else
				throw new ProductException("No relevant matches, Please check product ID");
		}
		return null;
	}

	@Override
	public Product searchProductbyCategory(ProductDto productDto) {
		List<Product> allproducts = productRepository.findAll();
		for (Product product : allproducts) {
			if (productDto.getCategory().equals(product.getCategory()))
				return product;
			else
				throw new ProductException("No relevant matches, Please check product Category");
		}
		return null;

	}

	@Override
	public Product searchProductbyName(ProductDto productDto) {
		List<Product> allproducts = productRepository.findAll();
		for (Product product : allproducts) {
			if (productDto.getName().equals(product.getName()))
				return product;
			else
				throw new ProductException("No relevant matches, Please check product Name");
		}
		return null;
	}
//List products 

	@Override
	public List<Product> productList() {
		return productRepository.findAll();
	}

//Customer CRUD API's
	@Override
	public Customer updateCustomer(CustomerDto customerDto) {
		Customer customer = new Customer();
		BeanUtils.copyProperties(customerDto, customer);
		Customer founddata = customerRepository.findById(customer.getId())
				.orElseThrow(() -> new CredentialsException("no data found, please check the customerID"));
		if (founddata != null) {
			customer.setFirstName(customerDto.getFirstName());
			customer.setLastName(customerDto.getLastName());
			customer.setPhoneno(customerDto.getPhoneno());
//			customer.setBillingAddress(billingAddress);
//			customer.getCart().setCartId(cart.getCartId());
//			customer.setShippingAddress(shippingAddress);
			customerRepository.save(customer);
		}
		return customer;

	}

	@Override
	public void deleteCustomer(CustomerDto customerDto) {
		Customer customer = new Customer();
		BeanUtils.copyProperties(customerDto, customer);
		Customer founddata = customerRepository.findById(customer.getId())
				.orElseThrow(() -> new CredentialsException("No data found, please enter right Customer ID"));
		customerRepository.delete(founddata);
	}

	@Override
	public Customer getCustomer(CustomerDto customerDto) {
		Customer customer = new Customer();
		BeanUtils.copyProperties(customerDto, customer);
		return customerRepository.findById(customer.getId())
				.orElseThrow(() -> new CredentialsException("No data found,"));
	}

	@Override
	public SalesOrder createSalesOrder(AddressDto addressDto, CustomerDto customerDto) {
		Customer customer = new Customer();
		BeanUtils.copyProperties(customerDto, customer);
		cartRepository.findById(customer.getId()).orElseThrow(
				() -> new GeneralException("No Cart available in Id and hence no sales order is generated"));
		salesOrder.getCustomer();
		salesOrder.getBillingAddress();
		salesOrder.getCart();
		salesOrder.getShippingAddress();
		return salesOrderRepository.save(salesOrder);

	}

}
