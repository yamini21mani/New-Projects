package com.te.ecommerce.dto;

import lombok.Data;
@Data
public class SalesOrderDto {
	private Integer salesOrderId;
}
