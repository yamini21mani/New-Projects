package com.te.ecommerce.springsecurity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@EnableWebSecurity
@Configuration
public class WebConfig extends WebSecurityConfigurerAdapter {
	@Autowired
	private UserDetailsService detailsService;
	@Autowired
	private BCryptPasswordEncoder encoder;

	@Bean
	AuthenticationProvider provider() {
		DaoAuthenticationProvider daoAuthenticationProvider = new DaoAuthenticationProvider();
		daoAuthenticationProvider.setUserDetailsService(detailsService);
		daoAuthenticationProvider.setPasswordEncoder(encoder);
		return daoAuthenticationProvider;
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.csrf().disable();
//		http.authorizeRequests().antMatchers("/CUSTOMER/register").permitAll();
//		http.authorizeHttpRequests().antMatchers("/USER/**").authenticated().and().httpBasic();
		
//		http.authorizeRequests().antMatchers("/ADMIN/**").hasRole("ADMIN").and().formLogin().and().logout().logoutRequestMatcher(new AntPathRequestMatcher("/logout"));

		
//		http.authorizeRequests().antMatchers("/CUSTOMER/login").hasRole(null)
//		http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
		//http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()
		//.httpBasic();
	
	
	}

	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().antMatchers("/v2/api-docs", "/configuration/ui", "/swagger-resources/**",
				"/configuration/security", "/swagger-ui.html", "/webjars/**");
	}

}
