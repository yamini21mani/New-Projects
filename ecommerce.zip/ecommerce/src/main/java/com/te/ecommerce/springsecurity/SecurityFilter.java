//package com.te.ecommerce.springsecurity;
//
//import java.io.IOException;
//
//import javax.servlet.FilterChain;
//import javax.servlet.ServletException;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
//import org.springframework.stereotype.Component;
//import org.springframework.web.filter.OncePerRequestFilter;
//@Component
//@Configuration
//public class SecurityFilter extends OncePerRequestFilter {
//
//	@Autowired
//	private JwtUtil jwtUtil;
//
//	@Autowired
//	private UserDetailsService detailsService;
//
//	@Override
//	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
//			throws ServletException, IOException {
//		String token = request.getHeader("Authorization");
//		if (token != null) {
//			String userName = jwtUtil.getUserName(token);
//			if (userName != null && SecurityContextHolder.getContext().getAuthentication() == null) {
//				UserDetails loadUserByUsername = detailsService.loadUserByUsername(userName);
//
//				boolean validateToken = jwtUtil.validateToken(token, loadUserByUsername.getUsername());
//				if (validateToken) {
//					UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(
//							userName, loadUserByUsername.getPassword());
//					authenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
//					SecurityContextHolder.getContext().setAuthentication(authenticationToken);
//
//				}
//
//			}
//		}
//		filterChain.doFilter(request, response);
//
//	}
//
//}
