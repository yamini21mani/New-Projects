package com.te.ecommerce.dto;


import lombok.Data;
@Data

public class CartDto {
	private Integer cartId;
	private double totalPrice;
}
