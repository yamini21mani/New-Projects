package com.te.userservice.dto;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Component
public class DepartmentDto {
	private Integer deptId;
	private String deptName;
	private String deptLocation;
}
