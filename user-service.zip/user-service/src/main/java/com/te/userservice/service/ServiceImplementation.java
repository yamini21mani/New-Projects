package com.te.userservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.te.userservice.dto.DepartmentDto;
import com.te.userservice.dto.RegisterDto;
import com.te.userservice.dto.ResponseDto;
import com.te.userservice.entity.User;
import com.te.userservice.feign.DepartmentFeignClient;
import com.te.userservice.repository.UserRepository;

@Service
public class ServiceImplementation {
	@Autowired
	private UserRepository repository;
	@Autowired
	DepartmentFeignClient client;

	public User register(RegisterDto registerDto) {
		DepartmentDto dept = client.fetchDept(registerDto.getDeptId());
		User user = User.builder().userId(registerDto.getUserId()).userName(registerDto.getUserName())
				.contactNumber(registerDto.getContactNumber()).description(registerDto.getDescription())
				.deptName(dept.getDeptName()).build();
		return repository.save(user);

	}

	public User fetchUser(Integer userId) {
		return repository.findById(userId).orElse(null);

	}

	public ResponseDto fetchUserData(Integer userId, Integer deptId) {
		DepartmentDto dept = client.fetchDept(deptId);
		User user = repository.findById(userId).orElse(null);
		return ResponseDto.builder().departmentDto(dept).user(user).build();

	}

}
