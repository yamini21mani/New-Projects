package com.te.userservice.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class User {
	@Id
	private Integer userId;
	private String userName;
	private Long contactNumber;
	private String description;
	private String deptName;
	
	
}
