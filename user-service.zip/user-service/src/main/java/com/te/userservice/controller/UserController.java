package com.te.userservice.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.te.userservice.UserResponse;
import com.te.userservice.dto.RegisterDto;
import com.te.userservice.dto.ResponseDto;
import com.te.userservice.entity.User;
import com.te.userservice.service.ServiceImplementation;

import io.github.resilience4j.ratelimiter.RequestNotPermitted;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;

@RequestMapping("/USER")
@RestController
public class UserController {
	Logger logger = LoggerFactory.getLogger(UserController.class);

	@Autowired
	private ServiceImplementation implementation;

	@PostMapping("/DISPLAY")
	@RateLimiter(name = "register", fallbackMethod = "getMessageFallBack")
	public ResponseEntity<UserResponse> register(@RequestBody RegisterDto registerDto) {
		User displayDetails = implementation.register(registerDto);
		UserResponse userResponse = UserResponse.builder().data(displayDetails).error("false")
				.message("registered successfully").build();
		return new ResponseEntity<>(userResponse, HttpStatus.ACCEPTED);

	}
	@PostMapping("/FETCH/{userId}")
	@RateLimiter(name = "fetchUser", fallbackMethod = "getMessageFallBack")
	public ResponseEntity<UserResponse> fetchUser(@PathVariable Integer userId) {
		User user = implementation.fetchUser(userId);
		UserResponse userResponse = UserResponse.builder().data(user).error("false")
				.message("registered successfully").build();
		return new ResponseEntity<>(userResponse, HttpStatus.ACCEPTED);

	}
	@PostMapping("/FETCH/DATA/{userId}/{deptId}")
	@RateLimiter(name = "fetchUserData", fallbackMethod = "getMessageFallBack")
	public ResponseEntity<UserResponse> fetchUserData(@PathVariable Integer userId,@PathVariable Integer deptId) {
		ResponseDto fetchUserData = implementation.fetchUserData(userId,deptId);
		UserResponse userResponse = UserResponse.builder().data(fetchUserData).error("false")
				.message("data fetched successfully").build();
		return new ResponseEntity<>(userResponse, HttpStatus.ACCEPTED);

	}
	public ResponseEntity<String> getMessageFallBack(RequestNotPermitted exception) {

		logger.info("Rate limit has applied, So no further calls are getting accepted");

		return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS)
				.body("Too many requests : No further request will be accepted. Please try after sometime");
	}
	
	
}
