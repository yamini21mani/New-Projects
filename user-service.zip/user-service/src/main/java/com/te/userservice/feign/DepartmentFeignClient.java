package com.te.userservice.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.te.userservice.dto.DepartmentDto;
@Component
@FeignClient(name = "DEPARTMENT-SERVICE")
public interface DepartmentFeignClient {
		

	@PostMapping("/DEPARTMENT/FETCH/{deptId}")
	public DepartmentDto fetchDept(@PathVariable Integer deptId);

}
