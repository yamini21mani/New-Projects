package com.te.jretests.dto;

public class ExamCreationDto {

}
