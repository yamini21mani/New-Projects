package com.te.jretests.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.te.jretests.dto.ExamAnswerDto;
import com.te.jretests.dto.ExamSchedulerDto;
import com.te.jretests.dto.QuestionUpdateDto;
import com.te.jretests.dto.QuestionsCreationDto;
import com.te.jretests.dto.SubjectCreationDto;
import com.te.jretests.dto.SubjectUpdationDto;
import com.te.jretests.entity.ExamScheduler;
import com.te.jretests.entity.Instructions;
import com.te.jretests.entity.Questions;
import com.te.jretests.entity.SubjectCategory;

@Service
public interface AdminService {
//Subject CRUD
	public SubjectCategory createSubject(SubjectCreationDto creationDto);

	public SubjectCategory getSubject(String subCode);

	public SubjectCategory updateSubject(SubjectUpdationDto updationDto);

	public void deleteSubject(String subCode);

//Questions CRUD
	public Questions creationQuestions(QuestionsCreationDto creationDto, String subCode);

	public Questions fetchQuestions(Integer questionNo);

	public Questions updateQuestions(QuestionUpdateDto updateDto);

	public void deleteQuestions(Integer questionNo);

	public Integer checkAnswer(ExamAnswerDto answerDto);

	public Map<String, Map<String, List<String>>> questionsList(String subCode);

	public Map<String, List<String>> fetchQuestions(String subCode);

//Exam Schedule CRUD
	public ExamScheduler addExamDate(ExamSchedulerDto schedulerDto);

	public ExamScheduler fetchExamDate(String schedulerId);

	public void deleteExamDate(String schedulerId);

	public List<ExamScheduler> displayExamSchedule();

	public List<Instructions> addInstructions(List<String> instructions);

	public List<Instructions> fetchInstructions();

	public List<Instructions> updateInstructions(Integer instructionId, String instruction);

	public void deleteInstructions(Integer instructionId);

}
