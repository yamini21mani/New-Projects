package com.te.jretests.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.te.jretests.entity.Questions;

public interface QuestionsRepository extends JpaRepository<Questions, Integer> {

}
