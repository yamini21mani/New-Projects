package com.te.jretests.entity;

public enum ExamLevel {
	ENTRY, INTERMEDIATE, ADVANCED
}
