package com.te.jretests.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.te.jretests.constants.Messages;
import com.te.jretests.dto.ExamAnswerDto;
import com.te.jretests.dto.ExamSchedulerDto;
import com.te.jretests.dto.QuestionUpdateDto;
import com.te.jretests.dto.QuestionsCreationDto;
import com.te.jretests.dto.SubjectCreationDto;
import com.te.jretests.dto.SubjectUpdationDto;
import com.te.jretests.entity.ExamScheduler;
import com.te.jretests.entity.Instructions;
import com.te.jretests.entity.Questions;
import com.te.jretests.entity.SubjectCategory;
import com.te.jretests.response.DisplayExamScheduleResponse;
import com.te.jretests.response.DisplayQuestionsResponse;
import com.te.jretests.response.InstructionsResponse;
import com.te.jretests.response.JreResponse;
import com.te.jretests.service.AdminService;

@RestController
@RequestMapping("/ADMIN")
public class AdminController {
	
	private static final Logger log = LoggerFactory.getLogger(AdminController.class);
	

	// Subject CRUD
	@Autowired
	private AdminService adminService;

	@PostMapping("/ADDSUBJECT")
	public ResponseEntity<JreResponse> createSubject(@RequestBody SubjectCreationDto creationDto) {
		SubjectCategory createSubject = adminService.createSubject(creationDto);
		log.info("subject category is created successfully");
		JreResponse jreResponse = JreResponse.builder().data(createSubject).message(Messages.CREATED).error(202)
				.build();
		return new ResponseEntity<>(jreResponse, HttpStatus.CREATED);

	}

	@GetMapping("/FETCHSUBJECT")
	public ResponseEntity<JreResponse> getSubject(@RequestParam String subCode) {
		SubjectCategory createSubject = adminService.getSubject(subCode);
		log.info("subject category is fetched successfully");
		JreResponse jreResponse = JreResponse.builder().data(createSubject).message(Messages.FETCHED).error(302)
				.build();
		return new ResponseEntity<>(jreResponse, HttpStatus.FOUND);

	}

	@PutMapping("/UPDATESUBJECT")
	public ResponseEntity<JreResponse> updateSubject(@RequestBody SubjectUpdationDto updationDto) {
		SubjectCategory createSubject = adminService.updateSubject(updationDto);
		JreResponse jreResponse = JreResponse.builder().data(createSubject).message(Messages.UPDATED).error(202)
				.build();
		log.info("subject category is updated successfully");
		return new ResponseEntity<>(jreResponse, HttpStatus.ACCEPTED);

	}

	@DeleteMapping("/DELETESUBJECT")
	public ResponseEntity<JreResponse> deleteSubject(@RequestParam String subCode) {
		adminService.deleteSubject(subCode);
		log.info("subject category is deleted successfully");
		JreResponse jreResponse = JreResponse.builder().message(Messages.DELETED).error(200).build();
		return new ResponseEntity<>(jreResponse, HttpStatus.OK);

	}

//Questions
	@PostMapping("/ADDQUESTION")
	public ResponseEntity<JreResponse> addQuestions(@RequestBody QuestionsCreationDto creationDto,
			@RequestParam String subCode) {
		Questions creationQuestions = adminService.creationQuestions(creationDto, subCode);
		log.info("question is created successfully");
		JreResponse jreResponse = JreResponse.builder().data(creationQuestions).message(Messages.CREATED).error(202)
				.build();
		return new ResponseEntity<>(jreResponse, HttpStatus.CREATED);
	}

	@GetMapping("/FETCHQUESTION")
	public ResponseEntity<JreResponse> fetchQuestions(@RequestParam Integer questionNo) {
		Questions questions = adminService.fetchQuestions(questionNo);
		log.info("question is fetched successfully");
		JreResponse jreResponse = JreResponse.builder().data(questions).message(Messages.FETCHED).error(302).build();
		return new ResponseEntity<>(jreResponse, HttpStatus.FOUND);

	}

	@PutMapping("/UPDATEQUESTION")
	public ResponseEntity<JreResponse> updateQuestions(@RequestBody QuestionUpdateDto updateDto) {
		Questions questions = adminService.updateQuestions(updateDto);
		log.info("question is updated successfully");
		JreResponse jreResponse = JreResponse.builder().data(questions).message(Messages.UPDATED).error(200).build();
		return new ResponseEntity<>(jreResponse, HttpStatus.OK);

	}

	@DeleteMapping("/DELETEQUESTION")
	public ResponseEntity<JreResponse> deleteQuestions(@RequestParam Integer questionNo) {
		adminService.deleteQuestions(questionNo);
		log.info("question is deleted successfully");
		JreResponse jreResponse = JreResponse.builder().error(200).message(Messages.DELETED).build();
		return new ResponseEntity<>(jreResponse, HttpStatus.OK);

	}

	@GetMapping("/FETCHQuestionsONSubCode")
	public ResponseEntity<DisplayQuestionsResponse> fetchQuestions(@RequestParam String subCode) {
		Map<String, List<String>> questions = adminService.fetchQuestions(subCode);
		log.info("question set is created successfully");
		DisplayQuestionsResponse jreResponse = DisplayQuestionsResponse.builder().subCode(subCode).data(questions)
				.message(Messages.FETCHED).build();
		return new ResponseEntity<>(jreResponse, HttpStatus.OK);
	}

	@GetMapping("/questionsList")
	public ResponseEntity<DisplayQuestionsResponse> questionsList(@RequestParam String subCode) {
		Map<String, Map<String, List<String>>> questionsList = adminService.questionsList(subCode);
		log.info("question set is displayed successfully");
  		DisplayQuestionsResponse jreResponse = DisplayQuestionsResponse.builder().build();
		return new ResponseEntity<>(jreResponse, HttpStatus.FOUND);

	}

	@GetMapping("/checkAnswer")
	public ResponseEntity<JreResponse> checkAnswer(@RequestBody ExamAnswerDto answerDto) {
		Integer checkAnswer = adminService.checkAnswer(answerDto);
		log.info("Answer is verified successfully");
		if (checkAnswer == 1) {
			JreResponse jreResponse = JreResponse.builder().data(checkAnswer).message("Correct Answer").error(302)
					.build();
			return new ResponseEntity<>(jreResponse, HttpStatus.FOUND);

		} else {
			JreResponse jreResponse = JreResponse.builder().data(checkAnswer).message("Incorrect Answer").error(404)
					.build();
			return new ResponseEntity<>(jreResponse, HttpStatus.NOT_FOUND);
		}
	}

//	public ResponseEntity<JreResponse> recordAnswers(@Request)

//EXAM Schedule CRUD's

	@PostMapping({ "/AddExamSchedule", "/UpdateExamSchedule" })
	public ResponseEntity<JreResponse> addExamDate(@RequestBody ExamSchedulerDto schedulerDto) {
		ExamScheduler scheduler = adminService.addExamDate(schedulerDto);
		log.info("Exam Schedule is modified successfully");
		JreResponse jreResponse = JreResponse.builder().data(scheduler).error(202).message(Messages.CREATED).build();
		return new ResponseEntity<>(jreResponse, HttpStatus.CREATED);
	}

	@GetMapping("/FetchExamSchedule")
	public ResponseEntity<JreResponse> fetchExamDate(@RequestParam String schedulerId) {
		ExamScheduler scheduler = adminService.fetchExamDate(schedulerId);
		log.info("Exam Schedule is fetched successfully");
		JreResponse jreResponse = JreResponse.builder().data(scheduler).error(302).message(Messages.FETCHED).build();
		return new ResponseEntity<>(jreResponse, HttpStatus.FOUND);
	}

	@DeleteMapping("/deleteExamSchedule")
	public ResponseEntity<JreResponse> deleteExamDate(@RequestParam String schedulerId) {
		adminService.deleteExamDate(schedulerId);
		log.info("Exam Schedule is deleted successfully");
		JreResponse jreResponse = JreResponse.builder().error(200).message(Messages.DELETED).build();
		return new ResponseEntity<>(jreResponse, HttpStatus.OK);
	}

	@GetMapping("/displayExamSchedule")
	public ResponseEntity<DisplayExamScheduleResponse> displayExamSchedule() {
		List<ExamScheduler> schedule = adminService.displayExamSchedule();
		log.info("Exam Schedule is displayed successfully");
		DisplayExamScheduleResponse response = DisplayExamScheduleResponse.builder().schedule(schedule)
				.message(Messages.FETCHED).status(302).build();
		return new ResponseEntity<>(response, HttpStatus.FOUND);
	}

	// Instructions CRUD
	@PostMapping("/addInstructions")
	public ResponseEntity<InstructionsResponse> addInstructions(@RequestParam List<String> instructions) {
		List<Instructions> list = adminService.addInstructions(instructions);
		log.info("Instructions is added successfully");
		InstructionsResponse response = InstructionsResponse.builder().message(Messages.CREATED).rules(list).build();
		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}

	@GetMapping("/fetchInstructions")
	public ResponseEntity<InstructionsResponse> fetchInstructions() {
		List<Instructions> list = adminService.fetchInstructions();
		log.info("Instructions is fetched successfully");
		InstructionsResponse response = InstructionsResponse.builder().message(Messages.FETCHED).rules(list).build();
		return new ResponseEntity<>(response, HttpStatus.FOUND);
	}

	@PutMapping("/updateInstructions")
	public ResponseEntity<InstructionsResponse> updateInstructions(@RequestParam Integer instructionId,
			@RequestParam String instruction) {
		List<Instructions> list = adminService.updateInstructions(instructionId, instruction);
		log.info("Instructions is deleted successfully");
		InstructionsResponse response = InstructionsResponse.builder().message(Messages.UPDATED).rules(list).build();
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@DeleteMapping("/deleteInstructions")
	public ResponseEntity<JreResponse> deleteInstructions(@RequestParam Integer instructionId) {
		adminService.deleteInstructions(instructionId);
		log.info("Instructions is deleted successfully");
		JreResponse response = JreResponse.builder().message(Messages.DELETED).build();
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

}
