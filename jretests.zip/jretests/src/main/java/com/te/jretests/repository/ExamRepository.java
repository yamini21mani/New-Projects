package com.te.jretests.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.te.jretests.entity.Exam;

public interface ExamRepository extends JpaRepository<Exam, String> {

}
