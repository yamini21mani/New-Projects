package com.te.jretests.constants;

public class Messages {
	public static final String CREATED="DATA CREATED SUCCESSFULLY";
	public static final String FETCHED="DATA FETCHED SUCCESSFULLY";
	public static final String UPDATED="DATA UPDATED SUCCESSFULLY";
	public static final String DELETED="DATA DELETED SUCCESSFULLY";
}
