package com.te.jretests.service;

public interface ParticipantService {

}
