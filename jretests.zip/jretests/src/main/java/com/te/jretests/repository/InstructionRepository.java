package com.te.jretests.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.te.jretests.entity.Instructions;

public interface InstructionRepository extends JpaRepository<Instructions, Integer>{

}
