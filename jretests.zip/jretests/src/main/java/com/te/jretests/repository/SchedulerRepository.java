package com.te.jretests.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.te.jretests.entity.ExamScheduler;

public interface SchedulerRepository extends JpaRepository<ExamScheduler, String> {

}
