//package com.te.jretests.dto;
//
//public class ScheduleExamDto {
//
//	private 
//}
