package com.te.jretests.entity;

import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.CreationTimestamp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Data
@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
@Builder
@Entity
public class Exam {
	@Id
	private String examCode;
	@NotNull(message = "Exam name can't be empty")
	private String examName;
	@NotNull(message = "Exam duration can't be empty")
	private Time duration;
	@NotNull(message = "Exam level can't be empty")
	private ExamLevel level;
	@NotNull(message = "Exam instructions cannot be empty")
	@ElementCollection
	@JoinColumn
	private List<String> instructions;
	@NotNull(message = "Questions cannot be empty")
	@ElementCollection
	@JoinColumn
	private List<Questions> questions;
	@NotNull(message = "Exam date is mandatory")
	private LocalDate date;
	@NotNull(message = "exam start time mandatory")
	@CreationTimestamp
	private LocalTime startTime;
	@ManyToOne(cascade = CascadeType.ALL)
	private SubjectCategory category;

}
