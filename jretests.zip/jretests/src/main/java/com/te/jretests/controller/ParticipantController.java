package com.te.jretests.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.te.jretests.service.AdminService;

@RestController
public class ParticipantController {
	@Autowired
	private AdminService adminService;

	
	
}
