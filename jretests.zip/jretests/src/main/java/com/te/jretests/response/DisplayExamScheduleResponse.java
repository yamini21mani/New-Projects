package com.te.jretests.response;

import java.util.List;

import com.te.jretests.entity.ExamScheduler;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Data
@Builder
@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
public class DisplayExamScheduleResponse {
	private List<ExamScheduler> schedule;
	private String message;
	private Integer status;

}
