package com.te.jretests.exceptionhandling;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ExceptionController {

	@ExceptionHandler(CustomException.class)
	public ResponseEntity<JreExceptionResponse> customException(@RequestBody String message) {
		JreExceptionResponse response = JreExceptionResponse.builder().message(message).build();
		return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
	}
}
