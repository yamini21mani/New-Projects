package com.te.jretests.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.te.jretests.entity.SubjectCategory;

public interface SubjectRepository extends JpaRepository<SubjectCategory, String> {

}
