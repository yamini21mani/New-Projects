package com.te.jretests;

public class SubjectCreationTestDto {

}
