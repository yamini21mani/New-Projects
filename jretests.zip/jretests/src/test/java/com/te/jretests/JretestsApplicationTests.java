package com.te.jretests;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JretestsApplicationTests {

	@Test
	void contextLoads() {
	}

}
